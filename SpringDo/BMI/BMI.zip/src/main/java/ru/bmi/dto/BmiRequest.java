package ru.bmi.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class BmiRequest {

    @Schema(description = "Рост в метрах", example = "1.75")
    private double heightCm;

    @Schema(description = "Вес в килограммах, example = \"70\"")
    private double weightKg;

    @Schema(description = "Возраст в годах, example = \"35\"")
    private int age;

    @Schema(description = "Пол: MALE или FEMALE", example = "MALE")
    private Gender gender;

    public enum Gender {
        MALE, FEMALE
    }
}
